package main.model.vo;

public class Product {
	private String img;
	private String productName;
	private int price;
	private String brand;
	private int discountRate;
	private String color;
	private String count;
	
	public Product() {}

	public Product(String img, String productName, int price, String brand, int discountRate, String color,
			String count) {
		super();
		this.img = img;
		this.productName = productName;
		this.price = price;
		this.brand = brand;
		this.discountRate = discountRate;
		this.color = color;
		this.count = count;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public int getDiscountRate() {
		return discountRate;
	}

	public void setDiscountRate(int discountRate) {
		this.discountRate = discountRate;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getCount() {
		return count;
	}

	public void setCount(String count) {
		this.count = count;
	}
	
	
}
